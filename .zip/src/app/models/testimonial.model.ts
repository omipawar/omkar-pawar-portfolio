export interface Testimonial {
  id: number;
  name: string;
  position: string;
  content: string;
  avatar: string;
}